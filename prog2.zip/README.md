# AI_8Puzzle
Second programming assignment for AI. Solve the 8 puzzle using Lisp
